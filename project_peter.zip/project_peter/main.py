import requests
import bs4
url='https://btech.com/ar/catalogsearch/result/?q=camera'
page = requests.get(url)
soup = bs4.BeautifulSoup(page.content, "html.parser")

camara=soup.find_all('div',{'class':'plpContentWrapper'})

for n in camara:
    print(n.find('h2',{'class':'plpTitle'}).getText())
    print(n.find('span',{'class':'price-wrapper'}).getText())